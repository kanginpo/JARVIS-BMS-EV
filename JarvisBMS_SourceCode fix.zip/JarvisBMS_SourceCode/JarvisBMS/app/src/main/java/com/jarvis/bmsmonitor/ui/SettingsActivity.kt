package com.jarvis.bmsmonitor.ui

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.bmsmonitor.R
import com.jarvis.bmsmonitor.databinding.ActivitySettingsBinding
import com.jarvis.bmsmonitor.service.BmsService
import com.jarvis.bmsmonitor.util.AppPreferences
import com.jarvis.bmsmonitor.util.JarvisVoice

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefs: AppPreferences
    private var bmsService: BmsService? = null

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, service: IBinder) {
            bmsService = (service as BmsService.BmsBinder).getService()
        }
        override fun onServiceDisconnected(name: ComponentName) { bmsService = null }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Pengaturan"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        prefs = AppPreferences(this)
        bindService(Intent(this, BmsService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)

        loadSettings()
        setupListeners()
    }

    private fun loadSettings() {
        with(binding) {
            seekLowBattery.progress = prefs.lowBatteryPct
            tvLowBatteryValue.text = "${prefs.lowBatteryPct}%"
            seekCriticalBattery.progress = prefs.criticalBatteryPct
            tvCriticalBatteryValue.text = "${prefs.criticalBatteryPct}%"
            switchCharge90.isChecked = prefs.chargeNotify90
            switchCharge100.isChecked = prefs.chargeNotify100
            switchVoice.isChecked = prefs.voiceEnabled
            radioIndonesia.isChecked = prefs.voiceLanguage == "ID"
            radioEnglish.isChecked = prefs.voiceLanguage == "EN"
            switchNotif.isChecked = prefs.notifEnabled
            switchAutoReconnect.isChecked = prefs.autoReconnect
            seekTemperature.progress = prefs.highTempThreshold.toInt()
            tvTemperatureValue.text = "${prefs.highTempThreshold.toInt()}°C"
        }
    }

    private fun setupListeners() {
        with(binding) {
            seekLowBattery.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    val v = maxOf(progress, prefs.criticalBatteryPct + 5)
                    tvLowBatteryValue.text = "$v%"
                    prefs.lowBatteryPct = v
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })

            seekCriticalBattery.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    val v = minOf(progress, prefs.lowBatteryPct - 5)
                    tvCriticalBatteryValue.text = "$v%"
                    prefs.criticalBatteryPct = v
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })

            switchCharge90.setOnCheckedChangeListener { _, checked -> prefs.chargeNotify90 = checked }
            switchCharge100.setOnCheckedChangeListener { _, checked -> prefs.chargeNotify100 = checked }
            switchVoice.setOnCheckedChangeListener { _, checked -> prefs.voiceEnabled = checked }

            radioGroupLanguage.setOnCheckedChangeListener { group, checkedId ->
                val selectedId = group.checkedRadioButtonId
                val lang = if (selectedId == binding.radioEnglish.id) {
                    prefs.voiceLanguage = "EN"
                    JarvisVoice.Language.ENGLISH
                } else {
                    prefs.voiceLanguage = "ID"
                    JarvisVoice.Language.INDONESIA
                }
                bmsService?.updateVoiceLanguage(lang)
            }

            switchNotif.setOnCheckedChangeListener { _, checked -> prefs.notifEnabled = checked }
            switchAutoReconnect.setOnCheckedChangeListener { _, checked -> prefs.autoReconnect = checked }

            seekTemperature.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    tvTemperatureValue.text = "$progress°C"
                    prefs.highTempThreshold = progress.toFloat()
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })

            btnTestVoice.setOnClickListener {
                Toast.makeText(this@SettingsActivity, "Testing Jarvis voice...", Toast.LENGTH_SHORT).show()
                val testVoice = JarvisVoice(this@SettingsActivity)
                val lang = if (prefs.voiceLanguage == "EN")
                    JarvisVoice.Language.ENGLISH else JarvisVoice.Language.INDONESIA
                testVoice.init(lang, object : JarvisVoice.VoiceCallback {
                    override fun onReady() { testVoice.greet() }
                    override fun onError(msg: String) {}
                })
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    override fun onDestroy() {
        super.onDestroy()
        unbindService(serviceConnection)
    }
}
