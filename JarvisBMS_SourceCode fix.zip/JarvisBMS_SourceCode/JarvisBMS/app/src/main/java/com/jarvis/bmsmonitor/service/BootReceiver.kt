package com.jarvis.bmsmonitor.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.jarvis.bmsmonitor.util.AppPreferences

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON") {

            // Hanya auto-start jika ada device yang pernah terhubung
            val prefs = AppPreferences(context)
            if (prefs.deviceAddress != null && prefs.autoReconnect) {
                val serviceIntent = Intent(context, BmsService::class.java)
                ContextCompat.startForegroundService(context, serviceIntent)
            }
        }
    }
}
