package com.jarvis.bmsmonitor.ui

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.jarvis.bmsmonitor.R
import com.jarvis.bmsmonitor.bluetooth.JkBmsProtocol
import com.jarvis.bmsmonitor.databinding.ActivityMainBinding
import com.jarvis.bmsmonitor.service.BmsService
import com.jarvis.bmsmonitor.util.AppPreferences

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: AppPreferences
    private var bmsService: BmsService? = null
    private var isBound = false
    private var isConnected = false

    // Device hasil scan (dipilih dari ScanActivity)
    private var selectedDevice: BluetoothDevice? = null

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, service: IBinder) {
            val binder = service as BmsService.BmsBinder
            bmsService = binder.getService()
            isBound = true

            // Set callback untuk update UI
            bmsService?.onDataUpdate = { data -> runOnUiThread { updateDashboard(data) } }
            bmsService?.onConnectionChanged = { connected ->
                runOnUiThread { updateConnectionState(connected) }
            }
        }

        override fun onServiceDisconnected(name: ComponentName) {
            bmsService = null
            isBound = false
        }
    }

    // Permission launcher
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            startScanActivity()
        } else {
            Toast.makeText(this, "Izin Bluetooth diperlukan untuk scan perangkat", Toast.LENGTH_LONG).show()
        }
    }

    // Scan activity result
    private val scanLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val address = result.data?.getStringExtra("device_address")
            val name = result.data?.getStringExtra("device_name")
            if (address != null) {
                prefs.deviceAddress = address
                prefs.deviceName = name
                binding.tvDeviceName.text = name ?: "JK BMS"
                connectToBms()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        prefs = AppPreferences(this)

        setupUI()
        startAndBindService()
    }

    private fun setupUI() {
        // Tampilkan nama device tersimpan
        binding.tvDeviceName.text = prefs.deviceName ?: "Belum ada perangkat"

        // Tombol scan
        binding.btnScan.setOnClickListener {
            checkPermissionsAndScan()
        }

        // Tombol connect/disconnect
        binding.btnConnect.setOnClickListener {
            if (isConnected) {
                bmsService?.disconnect()
            } else {
                prefs.deviceAddress?.let { connectToBms() }
                    ?: checkPermissionsAndScan()
            }
        }
    }

    private fun connectToBms() {
        val address = prefs.deviceAddress ?: return
        // Service akan auto-connect saat start, atau bisa dipanggil manual
        val intent = Intent(this, BmsService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun checkPermissionsAndScan() {
        val permsNeeded = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (!hasPermission(Manifest.permission.BLUETOOTH_SCAN))
                permsNeeded.add(Manifest.permission.BLUETOOTH_SCAN)
            if (!hasPermission(Manifest.permission.BLUETOOTH_CONNECT))
                permsNeeded.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            if (!hasPermission(Manifest.permission.ACCESS_FINE_LOCATION))
                permsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!hasPermission(Manifest.permission.POST_NOTIFICATIONS))
                permsNeeded.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (permsNeeded.isEmpty()) startScanActivity()
        else permissionLauncher.launch(permsNeeded.toTypedArray())
    }

    private fun startScanActivity() {
        val intent = Intent(this, ScanActivity::class.java)
        scanLauncher.launch(intent)
    }

    private fun hasPermission(perm: String) =
        ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED

    private fun startAndBindService() {
        val intent = Intent(this, BmsService::class.java)
        ContextCompat.startForegroundService(this, intent)
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun updateDashboard(data: JkBmsProtocol.BmsData) {
        with(binding) {
            // SOC gauge
            tvSoc.text = "${data.soc}%"
            progressBattery.progress = data.soc
            setBatteryColor(data.soc, data.isCharging)

            // Voltage, Current, Power
            tvVoltage.text = String.format("%.2f V", data.voltage)
            tvCurrent.text = String.format("%.2f A", data.current)
            tvPower.text   = String.format("%.1f W", data.power)

            // Temperature
            tvTemp1.text = String.format("%.1f°C", data.temperature1)
            tvTemp2.text = String.format("%.1f°C", data.temperature2)

            // Status charging
            tvChargingStatus.text = if (data.isCharging) "⚡ Charging" else "🔋 Discharging"
            tvChargingStatus.setTextColor(
                getColor(if (data.isCharging) android.R.color.holo_green_light
                         else android.R.color.holo_orange_light)
            )

            // MOSFET status
            tvChargeMos.text = if (data.chargeMosfet) "ON ✓" else "OFF"
            tvDischargeMos.text = if (data.dischargeMosfet) "ON ✓" else "OFF"

            // Balance
            tvBalance.text = if (data.balanceActive) "Aktif ⚖️" else "Tidak aktif"

            // Capacity
            tvRemainCap.text = String.format("%.1f Ah", data.remainCapacity)
            tvNominalCap.text = String.format("%.1f Ah", data.nominalCapacity)
            tvCycleCount.text = "${data.cycleCount}x"

            // Cell voltages
            updateCellVoltages(data.cellVoltages)

            // Timestamp
            tvLastUpdate.text = "Update: ${java.text.SimpleDateFormat("HH:mm:ss",
                java.util.Locale.getDefault()).format(java.util.Date())}"
        }
    }

    private fun setBatteryColor(soc: Int, isCharging: Boolean) {
        val color = when {
            isCharging -> getColor(android.R.color.holo_green_light)
            soc <= 10  -> getColor(android.R.color.holo_red_light)
            soc <= 20  -> getColor(android.R.color.holo_orange_light)
            else       -> getColor(android.R.color.holo_green_light)
        }
        binding.tvSoc.setTextColor(color)
    }

    private fun updateCellVoltages(cells: List<Float>) {
        binding.tvCellVoltages.text = if (cells.isEmpty()) {
            "Tidak ada data cell"
        } else {
            cells.mapIndexed { i, v ->
                "Cell ${i + 1}: ${String.format("%.3f", v)}V"
            }.joinToString("  |  ")
        }
    }

    private fun updateConnectionState(connected: Boolean) {
        isConnected = connected
        with(binding) {
            if (connected) {
                tvConnectionStatus.text = "● Terhubung"
                tvConnectionStatus.setTextColor(getColor(android.R.color.holo_green_light))
                btnConnect.text = "Putuskan"
                layoutDashboard.visibility = View.VISIBLE
                layoutDisconnected.visibility = View.GONE
            } else {
                tvConnectionStatus.text = "○ Terputus"
                tvConnectionStatus.setTextColor(getColor(android.R.color.darker_gray))
                btnConnect.text = "Hubungkan"
                layoutDashboard.visibility = View.GONE
                layoutDisconnected.visibility = View.VISIBLE
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            R.id.menu_log -> {
                startActivity(Intent(this, LogActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) {
            unbindService(serviceConnection)
            isBound = false
        }
    }
}
