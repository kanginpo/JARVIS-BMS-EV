package com.jarvis.bmsmonitor.util

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class JarvisVoice(private val context: Context) {

    private var tts: TextToSpeech? = null
    private var isReady = false
    private var language: Language = Language.INDONESIA

    enum class Language { INDONESIA, ENGLISH }

    interface VoiceCallback {
        fun onReady()
        fun onError(msg: String)
    }

    fun init(lang: Language = Language.INDONESIA, callback: VoiceCallback? = null) {
        language = lang
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val locale = when (lang) {
                    Language.INDONESIA -> Locale("id", "ID")
                    Language.ENGLISH   -> Locale.US
                }
                val result = tts?.setLanguage(locale)
                if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    // Fallback ke English
                    tts?.setLanguage(Locale.US)
                }
                // Sesuaikan pitch & speed agar terdengar seperti Jarvis
                tts?.setPitch(0.85f)      // Sedikit lebih dalam
                tts?.setSpeechRate(0.95f) // Sedikit lebih lambat & tegas
                isReady = true
                callback?.onReady()
            } else {
                callback?.onError("TTS tidak bisa diinisialisasi")
            }
        }
    }

    fun setLanguage(lang: Language) {
        language = lang
        val locale = when (lang) {
            Language.INDONESIA -> Locale("id", "ID")
            Language.ENGLISH   -> Locale.US
        }
        tts?.setLanguage(locale)
    }

    fun speak(text: String, utteranceId: String = "jarvis_${System.currentTimeMillis()}") {
        if (!isReady) return
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, utteranceId)
    }

    // ═══════════════════════════════════════════
    // JARVIS NOTIFICATIONS - Battery Low
    // ═══════════════════════════════════════════
    fun notifyBatteryLow(soc: Int) {
        val text = when (language) {
            Language.INDONESIA ->
                "Perhatian. Level baterai saat ini $soc persen. " +
                "Mohon segera hubungkan ke sumber daya."
            Language.ENGLISH ->
                "Attention. Battery level is now at $soc percent. " +
                "I recommend connecting to a power source immediately."
        }
        speak(text, "battery_low")
    }

    fun notifyBatteryCritical(soc: Int) {
        val text = when (language) {
            Language.INDONESIA ->
                "Peringatan kritis! Baterai hanya tersisa $soc persen. " +
                "Sistem mungkin akan segera mati."
            Language.ENGLISH ->
                "Critical warning! Battery level is dangerously low at $soc percent. " +
                "System shutdown may be imminent."
        }
        speak(text, "battery_critical")
    }

    // ═══════════════════════════════════════════
    // JARVIS NOTIFICATIONS - Charging
    // ═══════════════════════════════════════════
    fun notifyCharging90() {
        val text = when (language) {
            Language.INDONESIA ->
                "Pengisian baterai mencapai 90 persen. " +
                "Anda dapat mencabut charger sebentar lagi untuk menjaga kesehatan baterai."
            Language.ENGLISH ->
                "Battery charging has reached 90 percent. " +
                "You may disconnect the charger shortly to preserve battery health."
        }
        speak(text, "charging_90")
    }

    fun notifyChargingFull() {
        val text = when (language) {
            Language.INDONESIA ->
                "Baterai telah terisi penuh 100 persen. " +
                "Silakan cabut charger sekarang."
            Language.ENGLISH ->
                "Battery is now fully charged at 100 percent. " +
                "Please disconnect the charger now."
        }
        speak(text, "charging_full")
    }

    // ═══════════════════════════════════════════
    // JARVIS NOTIFICATIONS - Connection
    // ═══════════════════════════════════════════
    fun notifyConnected(deviceName: String) {
        val text = when (language) {
            Language.INDONESIA ->
                "Koneksi berhasil. Sistem B M S aktif dan siap dimonitor."
            Language.ENGLISH ->
                "Connection established. B M S system is online and ready for monitoring."
        }
        speak(text, "connected")
    }

    fun notifyDisconnected() {
        val text = when (language) {
            Language.INDONESIA ->
                "Koneksi ke B M S terputus. Mencoba menghubungkan kembali."
            Language.ENGLISH ->
                "B M S connection lost. Attempting to reconnect."
        }
        speak(text, "disconnected")
    }

    // ═══════════════════════════════════════════
    // JARVIS NOTIFICATIONS - Temperature
    // ═══════════════════════════════════════════
    fun notifyHighTemperature(temp: Float) {
        val tempInt = temp.toInt()
        val text = when (language) {
            Language.INDONESIA ->
                "Peringatan suhu. Temperatur baterai mencapai $tempInt derajat Celsius. " +
                "Mohon periksa sistem pendingin."
            Language.ENGLISH ->
                "Temperature warning. Battery temperature has reached $tempInt degrees Celsius. " +
                "Please check the cooling system."
        }
        speak(text, "high_temp")
    }

    // ═══════════════════════════════════════════
    // JARVIS - Welcome greeting
    // ═══════════════════════════════════════════
    fun greet() {
        val text = when (language) {
            Language.INDONESIA ->
                "Selamat datang. Sistem Jarvis B M S Monitor siap digunakan. " +
                "Semua sistem berjalan normal."
            Language.ENGLISH ->
                "Welcome back. Jarvis B M S Monitor system is online. " +
                "All systems are running normally."
        }
        speak(text, "greet")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isReady = false
    }
}
