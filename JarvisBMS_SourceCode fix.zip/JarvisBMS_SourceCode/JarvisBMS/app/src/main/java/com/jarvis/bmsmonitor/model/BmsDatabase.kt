package com.jarvis.bmsmonitor.model

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.*

// ═══════════════════════════════════════════════
// ENTITY
// ═══════════════════════════════════════════════
@Entity(tableName = "bms_log")
data class BmsLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val soc: Int,
    val voltage: Float,
    val current: Float,
    val power: Float,
    val temperature1: Float,
    val temperature2: Float,
    val isCharging: Boolean,
    val event: String = ""  // "LOW_BATTERY", "CHARGING_90", "CHARGING_FULL", "HIGH_TEMP", ""
) {
    fun formattedTime(): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
}

// ═══════════════════════════════════════════════
// DAO
// ═══════════════════════════════════════════════
@Dao
interface BmsLogDao {

    @Insert
    suspend fun insert(log: BmsLog)

    @Query("SELECT * FROM bms_log ORDER BY timestamp DESC LIMIT 500")
    fun getAllLogs(): Flow<List<BmsLog>>

    @Query("SELECT * FROM bms_log WHERE event != '' ORDER BY timestamp DESC LIMIT 100")
    fun getEventLogs(): Flow<List<BmsLog>>

    @Query("SELECT * FROM bms_log ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentLogs(limit: Int): List<BmsLog>

    @Query("DELETE FROM bms_log WHERE timestamp < :cutoff")
    suspend fun deleteOlderThan(cutoff: Long)

    @Query("DELETE FROM bms_log")
    suspend fun deleteAll()
}

// ═══════════════════════════════════════════════
// DATABASE
// ═══════════════════════════════════════════════
@Database(entities = [BmsLog::class], version = 1, exportSchema = false)
abstract class BmsDatabase : RoomDatabase() {
    abstract fun bmsLogDao(): BmsLogDao

    companion object {
        @Volatile private var INSTANCE: BmsDatabase? = null

        fun getInstance(context: android.content.Context): BmsDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BmsDatabase::class.java,
                    "jarvis_bms_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
