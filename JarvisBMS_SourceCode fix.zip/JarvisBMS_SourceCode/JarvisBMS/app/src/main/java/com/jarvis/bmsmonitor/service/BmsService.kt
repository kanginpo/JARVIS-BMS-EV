package com.jarvis.bmsmonitor.service

import android.app.Service
import android.content.pm.ServiceInfo
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.jarvis.bmsmonitor.bluetooth.BleManager
import com.jarvis.bmsmonitor.bluetooth.JkBmsProtocol
import com.jarvis.bmsmonitor.model.BmsDatabase
import com.jarvis.bmsmonitor.model.BmsLog
import com.jarvis.bmsmonitor.util.AppPreferences
import com.jarvis.bmsmonitor.util.JarvisVoice
import com.jarvis.bmsmonitor.util.NotifHelper
import kotlinx.coroutines.*

class BmsService : Service() {

    // Binder untuk komunikasi dengan Activity
    inner class BmsBinder : Binder() {
        fun getService() = this@BmsService
    }

    private val binder = BmsBinder()
    private lateinit var bleManager: BleManager
    private lateinit var jarvisVoice: JarvisVoice
    private lateinit var prefs: AppPreferences
    private lateinit var db: BmsDatabase
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val handler = Handler(Looper.getMainLooper())

    // State tracking untuk notifikasi (agar tidak spam)
    private var lastNotifiedSoc = -1
    private var hasNotified90 = false
    private var hasNotifiedFull = false
    private var hasNotifiedLow = false
    private var hasNotifiedCritical = false
    private var wasCharging = false

    // Callback ke Activity
    var onDataUpdate: ((JkBmsProtocol.BmsData) -> Unit)? = null
    var onConnectionChanged: ((Boolean) -> Unit)? = null

    // Auto reconnect
    private var reconnectAttempts = 0
    private val maxReconnectAttempts = 5

    override fun onCreate() {
        super.onCreate()
        prefs = AppPreferences(this)
        db = BmsDatabase.getInstance(this)
        bleManager = BleManager(this)
        jarvisVoice = JarvisVoice(this)

        NotifHelper.createChannels(this)

        // Init Jarvis Voice
        val lang = if (prefs.voiceLanguage == "EN")
            JarvisVoice.Language.ENGLISH else JarvisVoice.Language.INDONESIA
        jarvisVoice.init(lang)

        setupBleCallback()

        // Mulai sebagai foreground service
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NotifHelper.NOTIF_SERVICE_ID,
                NotifHelper.buildServiceNotification(this, "Menginisialisasi..."),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
        } else {
            startForeground(
                NotifHelper.NOTIF_SERVICE_ID,
                NotifHelper.buildServiceNotification(this, "Menginisialisasi...")
            )
        }

        // Auto connect jika ada device tersimpan
        prefs.deviceAddress?.let { address ->
            handler.postDelayed({ bleManager.connect(address) }, 2000)
        }

        // Bersihkan log lama setiap hari (simpan 7 hari terakhir)
        scope.launch {
            val cutoff = System.currentTimeMillis() - (7 * 24 * 60 * 60 * 1000L)
            db.bmsLogDao().deleteOlderThan(cutoff)
        }
    }

    private fun setupBleCallback() {
        bleManager.setCallback(object : BleManager.BleCallback {

            override fun onDeviceFound(device: BluetoothDevice) {
                // Diteruskan ke Activity lewat scan activity
            }

            override fun onConnected(address: String) {
                reconnectAttempts = 0
                onConnectionChanged?.invoke(true)
                updateServiceNotif("Terhubung ke ${prefs.deviceName ?: "JK BMS"}")

                if (prefs.voiceEnabled) {
                    jarvisVoice.notifyConnected(prefs.deviceName ?: "JK BMS")
                }
            }

            override fun onDisconnected() {
                onConnectionChanged?.invoke(false)
                updateServiceNotif("Terputus - Menghubungkan kembali...")

                if (prefs.voiceEnabled) {
                    jarvisVoice.notifyDisconnected()
                }

                // Auto reconnect
                if (prefs.autoReconnect && reconnectAttempts < maxReconnectAttempts) {
                    reconnectAttempts++
                    val delay = (reconnectAttempts * 5000).toLong()
                    handler.postDelayed({
                        prefs.deviceAddress?.let { bleManager.connect(it) }
                    }, delay)
                }
            }

            override fun onDataReceived(data: JkBmsProtocol.BmsData) {
                // Kirim ke Activity untuk update UI
                onDataUpdate?.invoke(data)

                // Update service notification
                val statusText = if (data.isCharging)
                    "⚡ Charging ${data.soc}% | ${data.voltage}V | ${data.current}A"
                else
                    "🔋 ${data.soc}% | ${data.voltage}V | ${data.current}A"
                updateServiceNotif(statusText)

                // Cek threshold dan kirim notifikasi
                checkAlerts(data)

                // Simpan ke log (setiap 30 detik atau ada event)
                saveToLog(data)
            }

            override fun onError(message: String) {
                updateServiceNotif("Error: $message")
            }
        })
    }

    private fun checkAlerts(data: JkBmsProtocol.BmsData) {
        val soc = data.soc

        // ── Reset flag saat charging dimulai ──
        if (data.isCharging && !wasCharging) {
            hasNotified90 = false
            hasNotifiedFull = false
            hasNotifiedLow = false
            hasNotifiedCritical = false
        }
        // ── Reset flag charging saat battery drain ──
        if (!data.isCharging && wasCharging) {
            hasNotified90 = false
            hasNotifiedFull = false
        }
        wasCharging = data.isCharging

        // ── ALERT: Battery Low ──
        if (!data.isCharging && soc <= prefs.lowBatteryPct && soc > prefs.criticalBatteryPct
            && !hasNotifiedLow) {
            hasNotifiedLow = true
            sendAlert(
                title = "⚠️ Baterai Lemah",
                message = "Level baterai $soc% - Segera charge!",
                event = "LOW_BATTERY"
            )
            if (prefs.voiceEnabled) jarvisVoice.notifyBatteryLow(soc)
        }

        // ── ALERT: Battery Critical ──
        if (!data.isCharging && soc <= prefs.criticalBatteryPct && !hasNotifiedCritical) {
            hasNotifiedCritical = true
            sendAlert(
                title = "🚨 Baterai Kritis!",
                message = "Level baterai $soc% - Sangat rendah!",
                event = "BATTERY_CRITICAL"
            )
            if (prefs.voiceEnabled) jarvisVoice.notifyBatteryCritical(soc)
        }

        // ── ALERT: Charging 90% ──
        if (data.isCharging && soc >= 90 && soc < 100
            && prefs.chargeNotify90 && !hasNotified90) {
            hasNotified90 = true
            sendAlert(
                title = "⚡ Charging 90%",
                message = "Baterai sudah 90%. Bisa dicabut sebentar lagi.",
                event = "CHARGING_90"
            )
            if (prefs.voiceEnabled) jarvisVoice.notifyCharging90()
        }

        // ── ALERT: Charging 100% ──
        if (data.isCharging && soc >= 100 && prefs.chargeNotify100 && !hasNotifiedFull) {
            hasNotifiedFull = true
            sendAlert(
                title = "✅ Baterai Penuh!",
                message = "Baterai sudah 100%. Silakan cabut charger.",
                event = "CHARGING_FULL"
            )
            if (prefs.voiceEnabled) jarvisVoice.notifyChargingFull()
        }

        // ── ALERT: High Temperature ──
        val maxTemp = maxOf(data.temperature1, data.temperature2)
        if (maxTemp >= prefs.highTempThreshold) {
            if (lastNotifiedSoc != soc) { // throttle dengan SOC change
                lastNotifiedSoc = soc
                sendAlert(
                    title = "🌡️ Suhu Tinggi!",
                    message = "Suhu baterai ${maxTemp.toInt()}°C - Melebihi batas aman!",
                    event = "HIGH_TEMP"
                )
                if (prefs.voiceEnabled) jarvisVoice.notifyHighTemperature(maxTemp)
            }
        }
    }

    private fun sendAlert(title: String, message: String, event: String) {
        if (prefs.notifEnabled) {
            NotifHelper.showAlert(this, title, message)
        }
    }

    // Simpan data ke Room setiap 30 detik atau saat ada event
    private var lastLogTime = 0L
    private fun saveToLog(data: JkBmsProtocol.BmsData, event: String = "") {
        val now = System.currentTimeMillis()
        if (event.isNotEmpty() || now - lastLogTime >= 30_000) {
            lastLogTime = now
            scope.launch {
                db.bmsLogDao().insert(
                    BmsLog(
                        soc = data.soc,
                        voltage = data.voltage,
                        current = data.current,
                        power = data.power,
                        temperature1 = data.temperature1,
                        temperature2 = data.temperature2,
                        isCharging = data.isCharging,
                        event = event
                    )
                )
            }
        }
    }

    private fun updateServiceNotif(text: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
        manager.notify(
            NotifHelper.NOTIF_SERVICE_ID,
            NotifHelper.buildServiceNotification(this, text)
        )
    }

    // Public methods dipanggil dari Activity
    fun startScan() = bleManager.startScan()
    fun stopScan()  = bleManager.stopScan()
    fun connectDevice(device: BluetoothDevice) {
        prefs.deviceAddress = device.address
        prefs.deviceName = device.name ?: "JK BMS"
        bleManager.connect(device)
    }
    fun disconnect() = bleManager.disconnect()

    fun updateVoiceLanguage(lang: JarvisVoice.Language) {
        jarvisVoice.setLanguage(lang)
    }

    override fun onBind(intent: Intent): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY // Service restart otomatis jika di-kill sistem
    }

    override fun onDestroy() {
        super.onDestroy()
        bleManager.disconnect()
        jarvisVoice.shutdown()
        scope.cancel()
    }
}
