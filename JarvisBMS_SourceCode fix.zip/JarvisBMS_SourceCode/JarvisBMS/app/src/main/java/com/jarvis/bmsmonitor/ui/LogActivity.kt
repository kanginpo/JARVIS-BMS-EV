package com.jarvis.bmsmonitor.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.jarvis.bmsmonitor.databinding.ActivityLogBinding
import com.jarvis.bmsmonitor.model.BmsDatabase
import com.jarvis.bmsmonitor.model.BmsLog
import kotlinx.coroutines.launch

class LogActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLogBinding
    private lateinit var db: BmsDatabase
    private var showEventsOnly = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLogBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Log History"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db = BmsDatabase.getInstance(this)
        binding.recyclerLog.layoutManager = LinearLayoutManager(this)

        setupUI()
        loadLogs()
    }

    private fun setupUI() {
        binding.toggleEvents.setOnCheckedChangeListener { _, isChecked ->
            showEventsOnly = isChecked
            loadLogs()
        }

        binding.btnClearLog.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Hapus Log")
                .setMessage("Hapus semua data log?")
                .setPositiveButton("Hapus") { _, _ ->
                    lifecycleScope.launch {
                        db.bmsLogDao().deleteAll()
                        loadLogs()
                    }
                }
                .setNegativeButton("Batal", null)
                .show()
        }
    }

    private fun loadLogs() {
        val flow = if (showEventsOnly)
            db.bmsLogDao().getEventLogs()
        else
            db.bmsLogDao().getAllLogs()

        lifecycleScope.launch {
            flow.collect { logs ->
                binding.recyclerLog.adapter = LogAdapter(logs)
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    // Simple RecyclerView adapter
    inner class LogAdapter(private val logs: List<BmsLog>) :
        RecyclerView.Adapter<LogAdapter.LogVH>() {

        inner class LogVH(val tv: TextView) : RecyclerView.ViewHolder(tv)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LogVH {
            val tv = TextView(parent.context).apply {
                setPadding(32, 16, 32, 16)
                textSize = 12f
            }
            return LogVH(tv)
        }

        override fun onBindViewHolder(holder: LogVH, position: Int) {
            val log = logs[position]
            val eventTag = if (log.event.isNotEmpty()) " [${log.event}]" else ""
            val chargingIcon = if (log.isCharging) "⚡" else "🔋"
            holder.tv.text =
                "${log.formattedTime()}$eventTag\n" +
                "$chargingIcon SOC: ${log.soc}% | ${String.format("%.2f",log.voltage)}V | " +
                "${String.format("%.2f",log.current)}A | ${String.format("%.1f",log.power)}W | " +
                "🌡️${log.temperature1.toInt()}°C"

            // Highlight event logs
            holder.tv.setBackgroundColor(
                if (log.event.isNotEmpty())
                    0x22FF9900.toInt() // orange tint
                else
                    android.graphics.Color.TRANSPARENT
            )
        }

        override fun getItemCount() = logs.size
    }
}
