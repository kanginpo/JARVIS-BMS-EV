package com.jarvis.bmsmonitor.util

import android.content.Context
import android.content.SharedPreferences

class AppPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("jarvis_bms_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_DEVICE_ADDRESS   = "device_address"
        private const val KEY_DEVICE_NAME      = "device_name"
        private const val KEY_LOW_BATTERY_PCT  = "low_battery_pct"
        private const val KEY_CRIT_BATTERY_PCT = "critical_battery_pct"
        private const val KEY_CHARGE_NOTIFY_90 = "charge_notify_90"
        private const val KEY_CHARGE_NOTIFY_100= "charge_notify_100"
        private const val KEY_VOICE_ENABLED    = "voice_enabled"
        private const val KEY_VOICE_LANGUAGE   = "voice_language"    // "ID" or "EN"
        private const val KEY_NOTIF_ENABLED    = "notif_enabled"
        private const val KEY_HIGH_TEMP_THRESH = "high_temp_threshold"
        private const val KEY_AUTO_RECONNECT   = "auto_reconnect"
    }

    // Device
    var deviceAddress: String?
        get() = prefs.getString(KEY_DEVICE_ADDRESS, null)
        set(v) = prefs.edit().putString(KEY_DEVICE_ADDRESS, v).apply()

    var deviceName: String?
        get() = prefs.getString(KEY_DEVICE_NAME, "JK BMS")
        set(v) = prefs.edit().putString(KEY_DEVICE_NAME, v).apply()

    // Battery thresholds
    var lowBatteryPct: Int
        get() = prefs.getInt(KEY_LOW_BATTERY_PCT, 20)
        set(v) = prefs.edit().putInt(KEY_LOW_BATTERY_PCT, v).apply()

    var criticalBatteryPct: Int
        get() = prefs.getInt(KEY_CRIT_BATTERY_PCT, 10)
        set(v) = prefs.edit().putInt(KEY_CRIT_BATTERY_PCT, v).apply()

    // Charging notifications
    var chargeNotify90: Boolean
        get() = prefs.getBoolean(KEY_CHARGE_NOTIFY_90, true)
        set(v) = prefs.edit().putBoolean(KEY_CHARGE_NOTIFY_90, v).apply()

    var chargeNotify100: Boolean
        get() = prefs.getBoolean(KEY_CHARGE_NOTIFY_100, true)
        set(v) = prefs.edit().putBoolean(KEY_CHARGE_NOTIFY_100, v).apply()

    // Voice
    var voiceEnabled: Boolean
        get() = prefs.getBoolean(KEY_VOICE_ENABLED, true)
        set(v) = prefs.edit().putBoolean(KEY_VOICE_ENABLED, v).apply()

    var voiceLanguage: String
        get() = prefs.getString(KEY_VOICE_LANGUAGE, "ID") ?: "ID"
        set(v) = prefs.edit().putString(KEY_VOICE_LANGUAGE, v).apply()

    // Notifications
    var notifEnabled: Boolean
        get() = prefs.getBoolean(KEY_NOTIF_ENABLED, true)
        set(v) = prefs.edit().putBoolean(KEY_NOTIF_ENABLED, v).apply()

    // Temperature
    var highTempThreshold: Float
        get() = prefs.getFloat(KEY_HIGH_TEMP_THRESH, 45f)
        set(v) = prefs.edit().putFloat(KEY_HIGH_TEMP_THRESH, v).apply()

    // Auto reconnect
    var autoReconnect: Boolean
        get() = prefs.getBoolean(KEY_AUTO_RECONNECT, true)
        set(v) = prefs.edit().putBoolean(KEY_AUTO_RECONNECT, v).apply()
}
