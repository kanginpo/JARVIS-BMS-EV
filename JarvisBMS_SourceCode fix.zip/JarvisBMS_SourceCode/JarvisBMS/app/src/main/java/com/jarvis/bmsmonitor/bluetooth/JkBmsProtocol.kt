package com.jarvis.bmsmonitor.bluetooth

/**
 * JK BMS BLE Protocol Constants & Parser
 *
 * JK BMS menggunakan BLE dengan karakteristik:
 * Service UUID  : 0000ffe0-0000-1000-8000-00805f9b34fb
 * Notify UUID   : 0000ffe1-0000-1000-8000-00805f9b34fb  (data dari BMS ke HP)
 * Write UUID    : 0000ffe1-0000-1000-8000-00805f9b34fb  (perintah dari HP ke BMS)
 *
 * Command untuk request data: 4E 57 00 13 00 00 00 00 06 03 00 00 00 00 00 00 68 00 00 01 29
 */
object JkBmsProtocol {

    // BLE UUIDs untuk JK BMS
    const val SERVICE_UUID    = "0000ffe0-0000-1000-8000-00805f9b34fb"
    const val NOTIFY_UUID     = "0000ffe1-0000-1000-8000-00805f9b34fb"
    const val WRITE_UUID      = "0000ffe1-0000-1000-8000-00805f9b34fb"

    // Header frame JK BMS
    private val FRAME_HEADER = byteArrayOf(0x4E, 0x57) // "NW"

    // Command request data BMS
    val CMD_GET_INFO: ByteArray = byteArrayOf(
        0x4E.toByte(), 0x57.toByte(), 0x00.toByte(), 0x13.toByte(),
        0x00.toByte(), 0x00.toByte(), 0x00.toByte(), 0x00.toByte(),
        0x06.toByte(), 0x03.toByte(), 0x00.toByte(), 0x00.toByte(),
        0x00.toByte(), 0x00.toByte(), 0x00.toByte(), 0x00.toByte(),
        0x68.toByte(), 0x00.toByte(), 0x00.toByte(), 0x01.toByte(),
        0x29.toByte()
    )

    // Data class hasil parsing
    data class BmsData(
        val soc: Int = 0,                    // State of Charge (%)
        val voltage: Float = 0f,             // Total voltage (V)
        val current: Float = 0f,             // Current (A), + = charging, - = discharging
        val power: Float = 0f,               // Power (W)
        val temperature1: Float = 0f,        // Suhu sensor 1 (°C)
        val temperature2: Float = 0f,        // Suhu sensor 2 (°C)
        val cellVoltages: List<Float> = emptyList(), // Tegangan tiap cell (V)
        val balanceActive: Boolean = false,  // Balance sedang aktif
        val chargeMosfet: Boolean = false,   // Status charge MOSFET
        val dischargeMosfet: Boolean = false,// Status discharge MOSFET
        val cycleCount: Int = 0,             // Jumlah siklus
        val remainCapacity: Float = 0f,      // Kapasitas sisa (Ah)
        val nominalCapacity: Float = 0f,     // Kapasitas nominal (Ah)
        val isCharging: Boolean = false,     // Sedang charging
        val timestamp: Long = System.currentTimeMillis()
    )

    // Buffer untuk menyimpan data yang masuk (JK BMS kadang kirim dalam beberapa paket)
    private val buffer = mutableListOf<Byte>()

    fun processData(rawBytes: ByteArray): BmsData? {
        // Tambahkan ke buffer
        rawBytes.forEach { buffer.add(it) }

        // Cari frame header 4E 57
        val headerIdx = findHeader() ?: return null

        // Pastikan minimal punya 4 byte untuk baca panjang frame
        if (buffer.size - headerIdx < 4) return null

        // Baca panjang frame (byte ke-2 dan ke-3 setelah header)
        val frameLen = ((buffer[headerIdx + 2].toInt() and 0xFF) shl 8) or
                       (buffer[headerIdx + 3].toInt() and 0xFF)

        val totalLen = frameLen + 4 // header (2) + length field (2) tidak dihitung dalam frameLen
        if (buffer.size - headerIdx < totalLen) return null

        // Ambil frame lengkap
        val frame = buffer.subList(headerIdx, headerIdx + totalLen).toByteArray()

        // Bersihkan buffer sampai setelah frame ini
        repeat(headerIdx + totalLen) { if (buffer.isNotEmpty()) buffer.removeAt(0) }

        return parseFrame(frame)
    }

    private fun findHeader(): Int? {
        for (i in 0 until buffer.size - 1) {
            if (buffer[i] == 0x4E.toByte() && buffer[i + 1] == 0x57.toByte()) {
                return i
            }
        }
        return null
    }

    fun clearBuffer() {
        buffer.clear()
    }

    private fun parseFrame(frame: ByteArray): BmsData? {
        return try {
            // Frame structure JK BMS:
            // [0-1]   : Header 4E 57
            // [2-3]   : Length
            // [4-7]   : BMS terminal number
            // [8]     : Command word (06 = info)
            // [9]     : Frame source
            // [10]    : Transport type
            // [11..N-4]: Data records
            // [N-3]   : End byte 68
            // [N-2..N]: CRC

            var idx = 11 // Mulai dari data records
            var soc = 0
            var voltage = 0f
            var current = 0f
            var temp1 = 0f
            var temp2 = 0f
            val cellVoltages = mutableListOf<Float>()
            var balanceActive = false
            var chargeMos = false
            var dischargeMos = false
            var cycleCount = 0
            var remainCap = 0f
            var nominalCap = 0f

            while (idx < frame.size - 4) {
                val recordType = frame[idx].toInt() and 0xFF
                idx++

                when (recordType) {
                    // Cell voltages (0x79 = cell info block)
                    0x79 -> {
                        val cellCount = (frame[idx].toInt() and 0xFF) / 3
                        idx++
                        for (c in 0 until cellCount) {
                            if (idx + 2 < frame.size) {
                                val mv = ((frame[idx].toInt() and 0xFF) shl 8) or
                                         (frame[idx + 1].toInt() and 0xFF)
                                cellVoltages.add(mv / 1000f)
                                idx += 3
                            }
                        }
                    }
                    // Average cell voltage
                    0x80 -> { idx += 2 }
                    // Delta cell voltage
                    0x81 -> { idx += 2 }
                    // Temperature 1
                    0x82 -> {
                        val raw = ((frame[idx].toInt() and 0xFF) shl 8) or
                                  (frame[idx + 1].toInt() and 0xFF)
                        temp1 = (raw - 2731) / 10f
                        idx += 2
                    }
                    // Temperature 2
                    0x83 -> {
                        val raw = ((frame[idx].toInt() and 0xFF) shl 8) or
                                  (frame[idx + 1].toInt() and 0xFF)
                        temp2 = (raw - 2731) / 10f
                        idx += 2
                    }
                    // Total voltage
                    0x84 -> {
                        val raw = ((frame[idx].toInt() and 0xFF) shl 8) or
                                  (frame[idx + 1].toInt() and 0xFF)
                        voltage = raw / 100f
                        idx += 2
                    }
                    // Current (signed)
                    0x85 -> {
                        val raw = ((frame[idx].toInt() and 0xFF) shl 8) or
                                  (frame[idx + 1].toInt() and 0xFF)
                        current = if (raw > 32767) (raw - 65536) / 100f else raw / 100f
                        idx += 2
                    }
                    // Remaining capacity
                    0x86 -> {
                        soc = frame[idx].toInt() and 0xFF
                        idx += 1
                    }
                    // Remaining capacity Ah
                    0x87 -> {
                        val raw = ((frame[idx].toInt() and 0xFF) shl 8) or
                                  (frame[idx + 1].toInt() and 0xFF)
                        remainCap = raw / 1000f
                        idx += 2
                    }
                    // Nominal capacity
                    0x89 -> {
                        val raw = ((frame[idx].toInt() and 0xFF) shl 24) or
                                  ((frame[idx+1].toInt() and 0xFF) shl 16) or
                                  ((frame[idx+2].toInt() and 0xFF) shl 8) or
                                  (frame[idx+3].toInt() and 0xFF)
                        nominalCap = raw / 1000f
                        idx += 4
                    }
                    // Cycle count
                    0x8A -> {
                        cycleCount = ((frame[idx].toInt() and 0xFF) shl 8) or
                                     (frame[idx + 1].toInt() and 0xFF)
                        idx += 2
                    }
                    // Balance status
                    0x8F -> {
                        balanceActive = (frame[idx].toInt() and 0xFF) != 0
                        idx += 2
                    }
                    // MOSFET status
                    0x8E -> {
                        val status = frame[idx].toInt() and 0xFF
                        chargeMos    = (status and 0x01) != 0
                        dischargeMos = (status and 0x02) != 0
                        idx += 1
                    }
                    // Skip unknown records (1 byte value by default)
                    else -> { idx += 1 }
                }
            }

            val power = voltage * current

            BmsData(
                soc = soc,
                voltage = voltage,
                current = current,
                power = power,
                temperature1 = temp1,
                temperature2 = temp2,
                cellVoltages = cellVoltages,
                balanceActive = balanceActive,
                chargeMosfet = chargeMos,
                dischargeMosfet = dischargeMos,
                cycleCount = cycleCount,
                remainCapacity = remainCap,
                nominalCapacity = nominalCap,
                isCharging = current > 0.1f
            )
        } catch (e: Exception) {
            null
        }
    }
}
