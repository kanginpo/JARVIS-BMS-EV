package com.jarvis.bmsmonitor.bluetooth

import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import java.util.UUID

class BleManager(private val context: Context) {

    interface BleCallback {
        fun onDeviceFound(device: BluetoothDevice)
        fun onConnected(address: String)
        fun onDisconnected()
        fun onDataReceived(data: JkBmsProtocol.BmsData)
        fun onError(message: String)
    }

    private var bluetoothGatt: BluetoothGatt? = null
    private var scanner: BluetoothLeScanner? = null
    private val handler = Handler(Looper.getMainLooper())
    private var callback: BleCallback? = null
    private var writeCharacteristic: BluetoothGattCharacteristic? = null
    private var isScanning = false

    // Kirim data request ke BMS setiap 2 detik
    private val pollRunnable = object : Runnable {
        override fun run() {
            requestBmsData()
            handler.postDelayed(this, 2000)
        }
    }

    fun setCallback(cb: BleCallback) {
        callback = cb
    }

    fun startScan() {
        val adapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager)
            .adapter ?: return
        scanner = adapter.bluetoothLeScanner
        isScanning = true

        val filter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid.fromString(JkBmsProtocol.SERVICE_UUID))
            .build()

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        scanner?.startScan(listOf(filter), settings, scanCallback)

        // Stop scan setelah 15 detik
        handler.postDelayed({
            stopScan()
        }, 15000)
    }

    fun stopScan() {
        if (isScanning) {
            scanner?.stopScan(scanCallback)
            isScanning = false
        }
    }

    fun connect(device: BluetoothDevice) {
        JkBmsProtocol.clearBuffer()
        bluetoothGatt = device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
    }

    fun connect(address: String) {
        val adapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager)
            .adapter ?: return
        val device = adapter.getRemoteDevice(address)
        connect(device)
    }

    fun disconnect() {
        handler.removeCallbacks(pollRunnable)
        bluetoothGatt?.disconnect()
        bluetoothGatt?.close()
        bluetoothGatt = null
        writeCharacteristic = null
    }

    private fun requestBmsData() {
        val characteristic = writeCharacteristic ?: return
        characteristic.value = JkBmsProtocol.CMD_GET_INFO
        characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        bluetoothGatt?.writeCharacteristic(characteristic)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            callback?.onDeviceFound(result.device)
        }

        override fun onScanFailed(errorCode: Int) {
            callback?.onError("Scan gagal: error $errorCode")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    handler.post { callback?.onConnected(gatt.device.address) }
                    gatt.discoverServices()
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    handler.removeCallbacks(pollRunnable)
                    handler.post { callback?.onDisconnected() }
                }
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            val service = gatt.getService(UUID.fromString(JkBmsProtocol.SERVICE_UUID))
                ?: run {
                    handler.post { callback?.onError("JK BMS service tidak ditemukan") }
                    return
                }

            // Setup notify characteristic
            val notifyChar = service.getCharacteristic(UUID.fromString(JkBmsProtocol.NOTIFY_UUID))
            gatt.setCharacteristicNotification(notifyChar, true)

            // Enable CCCD descriptor untuk notifikasi
            val cccd = notifyChar.getDescriptor(
                UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
            )
            cccd?.let {
                it.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                gatt.writeDescriptor(it)
            }

            // Simpan write characteristic
            writeCharacteristic = service.getCharacteristic(
                UUID.fromString(JkBmsProtocol.WRITE_UUID)
            )

            // Mulai polling data
            handler.postDelayed(pollRunnable, 1000)
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            if (characteristic.uuid == UUID.fromString(JkBmsProtocol.NOTIFY_UUID)) {
                val data = JkBmsProtocol.processData(characteristic.value) ?: return
                handler.post { callback?.onDataReceived(data) }
            }
        }

        override fun onCharacteristicWrite(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            // Write sukses, data akan masuk lewat notify
        }
    }
}
