package com.jarvis.bmsmonitor.ui

import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.bmsmonitor.bluetooth.BleManager
import com.jarvis.bmsmonitor.bluetooth.JkBmsProtocol
import com.jarvis.bmsmonitor.databinding.ActivityScanBinding

class ScanActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScanBinding
    private lateinit var bleManager: BleManager
    private val foundDevices = mutableListOf<BluetoothDevice>()
    private val deviceNames = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Cari Perangkat BMS"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        bleManager = BleManager(this)
        setupBleCallback()
        setupUI()
        startScan()
    }

    private fun setupUI() {
        binding.btnRescan.setOnClickListener { startScan() }
    }

    private fun startScan() {
        foundDevices.clear()
        deviceNames.clear()
        binding.progressScan.visibility = View.VISIBLE
        binding.tvScanStatus.text = "Mencari perangkat JK BMS..."
        binding.listView.adapter = null
        bleManager.startScan()
    }

    private fun setupBleCallback() {
        bleManager.setCallback(object : BleManager.BleCallback {
            override fun onDeviceFound(device: BluetoothDevice) {
                if (foundDevices.none { it.address == device.address }) {
                    foundDevices.add(device)
                    val name = device.name ?: "Unknown (${device.address})"
                    deviceNames.add(name)

                    runOnUiThread {
                        binding.tvScanStatus.text = "${foundDevices.size} perangkat ditemukan"
                        binding.progressScan.visibility = View.GONE

                        val adapter = android.widget.ArrayAdapter(
                            this@ScanActivity,
                            android.R.layout.simple_list_item_1,
                            deviceNames
                        )
                        binding.listView.adapter = adapter
                        binding.listView.setOnItemClickListener { _, _, position, _ ->
                            selectDevice(foundDevices[position])
                        }
                    }
                }
            }

            override fun onConnected(address: String) {}
            override fun onDisconnected() {}
            override fun onDataReceived(data: JkBmsProtocol.BmsData) {}

            override fun onError(message: String) {
                runOnUiThread {
                    binding.progressScan.visibility = View.GONE
                    binding.tvScanStatus.text = "Scan selesai"
                    Toast.makeText(this@ScanActivity, message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun selectDevice(device: BluetoothDevice) {
        bleManager.stopScan()
        val result = Intent().apply {
            putExtra("device_address", device.address)
            putExtra("device_name", device.name ?: "JK BMS")
        }
        setResult(RESULT_OK, result)
        finish()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    override fun onDestroy() {
        super.onDestroy()
        bleManager.stopScan()
    }
}
