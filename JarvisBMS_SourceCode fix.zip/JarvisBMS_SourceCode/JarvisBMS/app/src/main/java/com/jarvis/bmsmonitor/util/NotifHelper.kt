package com.jarvis.bmsmonitor.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.jarvis.bmsmonitor.R
import com.jarvis.bmsmonitor.ui.MainActivity

object NotifHelper {

    const val CHANNEL_SERVICE  = "bms_service"
    const val CHANNEL_ALERT    = "bms_alert"
    const val NOTIF_SERVICE_ID = 1001
    const val NOTIF_ALERT_ID   = 1002

    fun createChannels(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE)
                as NotificationManager

        // Channel untuk foreground service (silent)
        val serviceChannel = NotificationChannel(
            CHANNEL_SERVICE,
            "BMS Monitor Service",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Notifikasi service monitoring BMS berjalan di background"
            setShowBadge(false)
        }

        // Channel untuk alert (ada suara)
        val alertChannel = NotificationChannel(
            CHANNEL_ALERT,
            "BMS Alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notifikasi peringatan baterai dan charging"
            enableVibration(true)
        }

        manager.createNotificationChannel(serviceChannel)
        manager.createNotificationChannel(alertChannel)
    }

    fun buildServiceNotification(context: Context, status: String) =
        NotificationCompat.Builder(context, CHANNEL_SERVICE)
            .setContentTitle("Jarvis BMS Monitor")
            .setContentText(status)
            .setSmallIcon(R.drawable.ic_battery)
            .setOngoing(true)
            .setContentIntent(mainPendingIntent(context))
            .build()

    fun showAlert(context: Context, title: String, message: String) {
        val notif = NotificationCompat.Builder(context, CHANNEL_ALERT)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setSmallIcon(R.drawable.ic_battery)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(mainPendingIntent(context))
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE)
                as NotificationManager
        manager.notify(NOTIF_ALERT_ID, notif)
    }

    private fun mainPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
        return PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
